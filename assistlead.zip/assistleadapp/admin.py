from django.contrib import admin
from .models import Testtable,Company,Profile
# Register your models here.

admin.site.register(Testtable)
admin.site.register(Company)
admin.site.register(Profile)
