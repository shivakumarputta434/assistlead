from django.apps import AppConfig


class AssistleadappConfig(AppConfig):
    name = 'assistleadapp'
